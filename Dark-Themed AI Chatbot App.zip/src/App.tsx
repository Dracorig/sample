import { useState, useEffect, useRef } from "react";
import { AnimatePresence } from "motion/react";
import { ChatSidebar } from "./components/ChatSidebar";
import { ChatHeader } from "./components/ChatHeader";
import { ChatMessage } from "./components/ChatMessage";
import { ChatInput } from "./components/ChatInput";
import { TypingIndicator } from "./components/TypingIndicator";
import { EmptyState } from "./components/EmptyState";
import { ScrollArea } from "./components/ui/scroll-area";
import { toast } from "sonner@2.0.3";
import { Toaster } from "./components/ui/sonner";

interface Message {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: number;
}

interface Chat {
  id: string;
  title: string;
  timestamp: number;
  messages: Message[];
  model: string;
}

// Mock AI responses
const mockResponses = [
  "That's a great question! Let me help you with that. Based on my understanding, I can provide you with detailed insights and analysis.",
  "I appreciate your curiosity! Here's what I think about that topic. There are several perspectives we can explore together.",
  "Interesting point! From my training, I can share that this is a multifaceted topic with various considerations to keep in mind.",
  "I'm here to assist! Let me break this down for you in a way that's easy to understand and actionable.",
  "Thanks for asking! This reminds me of several related concepts that might be helpful for you to consider.",
];

export default function App() {
  const [chats, setChats] = useState<Chat[]>([]);
  const [currentChatId, setCurrentChatId] = useState<string | null>(null);
  const [isTyping, setIsTyping] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Load chats from localStorage on mount
  useEffect(() => {
    const savedChats = localStorage.getItem("ai-chats");
    const savedTheme = localStorage.getItem("ai-theme");
    
    if (savedChats) {
      const parsedChats = JSON.parse(savedChats);
      setChats(parsedChats);
      if (parsedChats.length > 0) {
        setCurrentChatId(parsedChats[0].id);
      }
    }

    if (savedTheme) {
      setIsDarkMode(savedTheme === "dark");
    }
  }, []);

  // Save chats to localStorage whenever they change
  useEffect(() => {
    if (chats.length > 0) {
      localStorage.setItem("ai-chats", JSON.stringify(chats));
    }
  }, [chats]);

  // Apply theme
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
    localStorage.setItem("ai-theme", isDarkMode ? "dark" : "light");
  }, [isDarkMode]);

  const currentChat = chats.find((chat) => chat.id === currentChatId);

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [currentChat?.messages, isTyping]);

  const createNewChat = () => {
    const newChat: Chat = {
      id: Date.now().toString(),
      title: `Chat ${chats.length + 1}`,
      timestamp: Date.now(),
      messages: [],
      model: "GPT-5",
    };
    setChats([newChat, ...chats]);
    setCurrentChatId(newChat.id);
    toast.success("New chat created!");
  };

  const deleteChat = (chatId: string) => {
    const updatedChats = chats.filter((chat) => chat.id !== chatId);
    setChats(updatedChats);
    
    if (currentChatId === chatId) {
      setCurrentChatId(updatedChats[0]?.id || null);
    }
    
    if (updatedChats.length === 0) {
      localStorage.removeItem("ai-chats");
    }
    
    toast.success("Chat deleted");
  };

  const renameChat = (chatId: string, newTitle: string) => {
    setChats(
      chats.map((chat) =>
        chat.id === chatId ? { ...chat, title: newTitle } : chat
      )
    );
    toast.success("Chat renamed");
  };

  const updateChatModel = (model: string) => {
    if (!currentChatId) return;
    
    setChats(
      chats.map((chat) =>
        chat.id === currentChatId ? { ...chat, model } : chat
      )
    );
    toast.success(`Switched to ${model}`);
  };

  const sendMessage = async (content: string) => {
    if (!currentChatId) {
      createNewChat();
      // Wait a bit for state to update, then retry
      setTimeout(() => sendMessage(content), 100);
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content,
      timestamp: Date.now(),
    };

    // Add user message
    setChats(
      chats.map((chat) =>
        chat.id === currentChatId
          ? { ...chat, messages: [...chat.messages, userMessage] }
          : chat
      )
    );

    // Update chat title based on first message
    if (currentChat && currentChat.messages.length === 0) {
      const title = content.slice(0, 30) + (content.length > 30 ? "..." : "");
      renameChat(currentChatId, title);
    }

    // Simulate AI typing
    setIsTyping(true);
    
    // Random delay between 1-3 seconds
    const delay = 1000 + Math.random() * 2000;
    
    setTimeout(() => {
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: mockResponses[Math.floor(Math.random() * mockResponses.length)],
        timestamp: Date.now(),
      };

      setChats(
        chats.map((chat) =>
          chat.id === currentChatId
            ? { ...chat, messages: [...chat.messages, userMessage, aiMessage] }
            : chat
        )
      );
      
      setIsTyping(false);
    }, delay);
  };

  const exportChat = () => {
    if (!currentChat) return;

    const chatText = currentChat.messages
      .map(
        (msg) =>
          `[${msg.role.toUpperCase()}] ${new Date(msg.timestamp).toLocaleString()}\n${msg.content}\n`
      )
      .join("\n");

    const blob = new Blob([chatText], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${currentChat.title}.txt`;
    a.click();
    URL.revokeObjectURL(url);
    
    toast.success("Chat exported!");
  };

  const regenerateResponse = () => {
    if (!currentChat || currentChat.messages.length === 0) return;

    // Remove last AI message if it exists
    const lastMessage = currentChat.messages[currentChat.messages.length - 1];
    if (lastMessage.role === "assistant") {
      setChats(
        chats.map((chat) =>
          chat.id === currentChatId
            ? { ...chat, messages: chat.messages.slice(0, -1) }
            : chat
        )
      );

      // Generate new response
      setIsTyping(true);
      setTimeout(() => {
        const newAiMessage: Message = {
          id: Date.now().toString(),
          role: "assistant",
          content: mockResponses[Math.floor(Math.random() * mockResponses.length)],
          timestamp: Date.now(),
        };

        setChats(
          chats.map((chat) =>
            chat.id === currentChatId
              ? { ...chat, messages: [...chat.messages, newAiMessage] }
              : chat
          )
        );
        
        setIsTyping(false);
      }, 1500);
      
      toast.success("Regenerating response...");
    }
  };

  return (
    <div className={`h-screen flex overflow-hidden ${isDarkMode ? 'dark' : ''}`}>
      <Toaster position="top-right" theme={isDarkMode ? "dark" : "light"} />
      
      {/* Background Effects */}
      <div className="fixed inset-0 bg-gradient-to-br from-black via-gray-900 to-black" />
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-purple-900/20 via-transparent to-transparent" />
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_bottom_left,_var(--tw-gradient-stops))] from-blue-900/20 via-transparent to-transparent" />

      {/* Sidebar */}
      <div className="relative w-80 flex-shrink-0 z-10">
        <ChatSidebar
          chats={chats}
          currentChatId={currentChatId}
          onSelectChat={setCurrentChatId}
          onNewChat={createNewChat}
          onDeleteChat={deleteChat}
          onRenameChat={renameChat}
        />
      </div>

      {/* Main Chat Area */}
      <div className="relative flex-1 flex flex-col z-10">
        {currentChat ? (
          <>
            {/* Header */}
            <ChatHeader
              chatTitle={currentChat.title}
              modelName={currentChat.model}
              onModelChange={updateChatModel}
              onExportChat={exportChat}
              onRegenerateResponse={regenerateResponse}
              isDarkMode={isDarkMode}
              onToggleTheme={() => setIsDarkMode(!isDarkMode)}
            />

            {/* Messages */}
            <ScrollArea className="flex-1">
              {currentChat.messages.length === 0 ? (
                <EmptyState />
              ) : (
                <div className="pb-4">
                  {currentChat.messages.map((message) => (
                    <ChatMessage
                      key={message.id}
                      role={message.role}
                      content={message.content}
                      timestamp={message.timestamp}
                    />
                  ))}
                  
                  <AnimatePresence>
                    {isTyping && <TypingIndicator />}
                  </AnimatePresence>
                  
                  <div ref={messagesEndRef} />
                </div>
              )}
            </ScrollArea>

            {/* Input */}
            <ChatInput onSendMessage={sendMessage} disabled={isTyping} />
          </>
        ) : (
          <div className="flex-1 flex flex-col">
            <EmptyState />
            <ChatInput
              onSendMessage={(content) => {
                createNewChat();
                setTimeout(() => sendMessage(content), 100);
              }}
              disabled={isTyping}
            />
          </div>
        )}
      </div>
    </div>
  );
}
