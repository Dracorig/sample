import { motion } from "motion/react";
import { Sparkles, Zap, Shield, Globe } from "lucide-react";

export function EmptyState() {
  const features = [
    { icon: Sparkles, title: "Creative Answers", desc: "Get imaginative solutions" },
    { icon: Zap, title: "Lightning Fast", desc: "Instant responses" },
    { icon: Shield, title: "Privacy First", desc: "Your data stays safe" },
    { icon: Globe, title: "Global Knowledge", desc: "Trained on diverse data" },
  ];

  return (
    <div className="flex-1 flex items-center justify-center p-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-3xl text-center space-y-8"
      >
        {/* Logo/Icon */}
        <motion.div
          animate={{
            scale: [1, 1.05, 1],
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut",
          }}
          className="inline-block"
        >
          <div className="w-20 h-20 mx-auto bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 rounded-3xl flex items-center justify-center shadow-2xl shadow-purple-500/30">
            <Sparkles className="h-10 w-10 text-white" />
          </div>
        </motion.div>

        {/* Title */}
        <div className="space-y-3">
          <h2 className="text-4xl bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
            Welcome to AI Chat
          </h2>
          <p className="text-gray-400 text-lg">
            Your intelligent assistant is ready to help. Start a conversation below.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-12">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              className="p-4 bg-white/5 backdrop-blur-sm rounded-xl border border-white/10 hover:bg-white/10 transition-all"
            >
              <feature.icon className="h-6 w-6 mx-auto mb-2 text-purple-400" />
              <div className="text-sm text-white mb-1">{feature.title}</div>
              <div className="text-xs text-gray-500">{feature.desc}</div>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </div>
  );
}
