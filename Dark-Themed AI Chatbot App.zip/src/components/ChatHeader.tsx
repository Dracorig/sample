import { ChevronDown, Download, RotateCcw, Sun, Moon } from "lucide-react";
import { Button } from "./ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";

interface ChatHeaderProps {
  chatTitle: string;
  modelName: string;
  onModelChange: (model: string) => void;
  onExportChat: () => void;
  onRegenerateResponse: () => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
}

export function ChatHeader({
  chatTitle,
  modelName,
  onModelChange,
  onExportChat,
  onRegenerateResponse,
  isDarkMode,
  onToggleTheme,
}: ChatHeaderProps) {
  const models = ["GPT-3.5 Turbo", "GPT-4", "GPT-5"];

  return (
    <div className="border-b border-white/10 bg-black/40 backdrop-blur-xl px-6 py-4">
      <div className="flex items-center justify-between">
        {/* Left: Title and Model */}
        <div className="flex items-center gap-4">
          <h1 className="text-white">{chatTitle}</h1>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant="ghost"
                className="text-gray-400 hover:text-white hover:bg-white/10 gap-2"
              >
                <span className="text-sm">{modelName}</span>
                <ChevronDown className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-black/90 backdrop-blur-xl border-white/10">
              {models.map((model) => (
                <DropdownMenuItem
                  key={model}
                  onClick={() => onModelChange(model)}
                  className="text-gray-300 hover:text-white hover:bg-white/10 cursor-pointer"
                >
                  {model}
                </DropdownMenuItem>
              ))}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2">
          <Button
            size="icon"
            variant="ghost"
            onClick={onRegenerateResponse}
            className="text-gray-400 hover:text-white hover:bg-white/10"
            title="Regenerate response"
          >
            <RotateCcw className="h-4 w-4" />
          </Button>

          <Button
            size="icon"
            variant="ghost"
            onClick={onExportChat}
            className="text-gray-400 hover:text-white hover:bg-white/10"
            title="Export chat"
          >
            <Download className="h-4 w-4" />
          </Button>

          <Button
            size="icon"
            variant="ghost"
            onClick={onToggleTheme}
            className="text-gray-400 hover:text-white hover:bg-white/10"
            title="Toggle theme"
          >
            {isDarkMode ? (
              <Sun className="h-4 w-4" />
            ) : (
              <Moon className="h-4 w-4" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
