import { useState, useRef, useEffect } from "react";
import { Send, Mic, Paperclip } from "lucide-react";
import { Button } from "./ui/button";
import { motion } from "motion/react";

interface ChatInputProps {
  onSendMessage: (message: string) => void;
  disabled?: boolean;
}

export function ChatInput({ onSendMessage, disabled }: ChatInputProps) {
  const [message, setMessage] = useState("");
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = `${textareaRef.current.scrollHeight}px`;
    }
  }, [message]);

  const handleSubmit = () => {
    if (message.trim() && !disabled) {
      onSendMessage(message.trim());
      setMessage("");
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="border-t border-white/10 bg-black/40 backdrop-blur-xl p-4">
      <div className="max-w-4xl mx-auto">
        <div className="relative bg-white/5 rounded-2xl border border-white/10 shadow-2xl shadow-purple-500/10 overflow-hidden">
          {/* Gradient Border Effect */}
          <div className="absolute inset-0 bg-gradient-to-r from-blue-500/20 to-purple-500/20 opacity-0 hover:opacity-100 transition-opacity pointer-events-none" />
          
          <div className="relative flex items-end gap-2 p-3">
            {/* Optional Icons */}
            <Button
              size="icon"
              variant="ghost"
              className="flex-shrink-0 text-gray-400 hover:text-white hover:bg-white/10 rounded-xl"
              disabled={disabled}
            >
              <Paperclip className="h-5 w-5" />
            </Button>

            {/* Textarea */}
            <textarea
              ref={textareaRef}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ask anything..."
              disabled={disabled}
              rows={1}
              className="flex-1 bg-transparent text-white placeholder:text-gray-500 outline-none resize-none max-h-32 py-2.5"
            />

            {/* Mic Button */}
            <Button
              size="icon"
              variant="ghost"
              className="flex-shrink-0 text-gray-400 hover:text-white hover:bg-white/10 rounded-xl"
              disabled={disabled}
            >
              <Mic className="h-5 w-5" />
            </Button>

            {/* Send Button */}
            <motion.div whileTap={{ scale: 0.95 }}>
              <Button
                size="icon"
                onClick={handleSubmit}
                disabled={!message.trim() || disabled}
                className="flex-shrink-0 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed rounded-xl shadow-lg shadow-purple-500/30"
              >
                <Send className="h-5 w-5" />
              </Button>
            </motion.div>
          </div>
        </div>

        {/* Helper Text */}
        <p className="text-center text-xs text-gray-500 mt-3">
          Press Enter to send, Shift+Enter for new line
        </p>
      </div>
    </div>
  );
}
