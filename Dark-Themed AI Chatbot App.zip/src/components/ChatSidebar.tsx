import { Plus, MessageSquare, Trash2, Edit2, Check, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { useState } from "react";
import { Button } from "./ui/button";
import { ScrollArea } from "./ui/scroll-area";

interface Chat {
  id: string;
  title: string;
  timestamp: number;
}

interface ChatSidebarProps {
  chats: Chat[];
  currentChatId: string | null;
  onSelectChat: (chatId: string) => void;
  onNewChat: () => void;
  onDeleteChat: (chatId: string) => void;
  onRenameChat: (chatId: string, newTitle: string) => void;
}

export function ChatSidebar({
  chats,
  currentChatId,
  onSelectChat,
  onNewChat,
  onDeleteChat,
  onRenameChat,
}: ChatSidebarProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");

  const startEditing = (chat: Chat) => {
    setEditingId(chat.id);
    setEditTitle(chat.title);
  };

  const saveEdit = (chatId: string) => {
    if (editTitle.trim()) {
      onRenameChat(chatId, editTitle.trim());
    }
    setEditingId(null);
  };

  const cancelEdit = () => {
    setEditingId(null);
    setEditTitle("");
  };

  return (
    <div className="h-full bg-black/40 backdrop-blur-xl border-r border-white/10 flex flex-col">
      {/* New Chat Button */}
      <div className="p-4 border-b border-white/10">
        <Button
          onClick={onNewChat}
          className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg shadow-purple-500/20 transition-all duration-300"
        >
          <Plus className="mr-2 h-4 w-4" />
          New Chat
        </Button>
      </div>

      {/* Chat List */}
      <ScrollArea className="flex-1">
        <div className="p-2 space-y-1">
          <AnimatePresence>
            {chats.map((chat) => (
              <motion.div
                key={chat.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="group relative"
              >
                <button
                  onClick={() => onSelectChat(chat.id)}
                  className={`w-full text-left px-3 py-2.5 rounded-lg transition-all duration-200 flex items-center gap-2 ${
                    currentChatId === chat.id
                      ? "bg-white/10 text-white shadow-md"
                      : "text-gray-400 hover:bg-white/5 hover:text-white"
                  }`}
                >
                  <MessageSquare className="h-4 w-4 flex-shrink-0" />
                  {editingId === chat.id ? (
                    <div className="flex-1 flex items-center gap-1" onClick={(e) => e.stopPropagation()}>
                      <input
                        type="text"
                        value={editTitle}
                        onChange={(e) => setEditTitle(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") saveEdit(chat.id);
                          if (e.key === "Escape") cancelEdit();
                        }}
                        className="flex-1 bg-white/10 text-white px-2 py-1 rounded text-sm outline-none"
                        autoFocus
                      />
                      <button
                        onClick={() => saveEdit(chat.id)}
                        className="p-1 hover:bg-white/10 rounded"
                      >
                        <Check className="h-3 w-3 text-green-400" />
                      </button>
                      <button
                        onClick={cancelEdit}
                        className="p-1 hover:bg-white/10 rounded"
                      >
                        <X className="h-3 w-3 text-red-400" />
                      </button>
                    </div>
                  ) : (
                    <span className="flex-1 truncate">{chat.title}</span>
                  )}
                </button>

                {/* Action Buttons */}
                {editingId !== chat.id && (
                  <div className="absolute right-2 top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        startEditing(chat);
                      }}
                      className="p-1.5 hover:bg-white/10 rounded text-gray-400 hover:text-white transition-colors"
                    >
                      <Edit2 className="h-3 w-3" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteChat(chat.id);
                      }}
                      className="p-1.5 hover:bg-red-500/20 rounded text-gray-400 hover:text-red-400 transition-colors"
                    >
                      <Trash2 className="h-3 w-3" />
                    </button>
                  </div>
                )}
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </ScrollArea>

      {/* Footer */}
      <div className="p-4 border-t border-white/10">
        <div className="flex items-center gap-3 text-gray-400">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
            <span className="text-white">U</span>
          </div>
          <div className="flex-1">
            <div className="text-sm text-white">User</div>
            <div className="text-xs">Free Plan</div>
          </div>
        </div>
      </div>
    </div>
  );
}
