
  # Dark-Themed AI Chatbot App

  This is a code bundle for Dark-Themed AI Chatbot App. The original project is available at https://www.figma.com/design/gUIDsC9knvNdIl4jl31TCO/Dark-Themed-AI-Chatbot-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  