
  # Personalized News Hub UI

  This is a code bundle for Personalized News Hub UI. The original project is available at https://www.figma.com/design/oATKgs54Lu4NIw0lyBeRmt/Personalized-News-Hub-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  