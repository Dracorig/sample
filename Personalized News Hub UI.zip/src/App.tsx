import { useState, useEffect, useMemo } from "react";
import { Navbar } from "./components/Navbar";
import { CategorySidebar } from "./components/CategorySidebar";
import { WeekAtGlance } from "./components/WeekAtGlance";
import { NewsFeed } from "./components/NewsFeed";
import { OnboardingModal } from "./components/OnboardingModal";
import { PreferencesDialog } from "./components/PreferencesDialog";
import { MOCK_NEWS } from "./data/mockNews";
import { NewsArticle } from "./components/NewsCard";

export default function App() {
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [userPreferences, setUserPreferences] = useState<string[]>([]);
  const [selectedCategory, setSelectedCategory] = useState("my-feed");
  const [searchQuery, setSearchQuery] = useState("");
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [preferencesOpen, setPreferencesOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  // Check for first-time user
  useEffect(() => {
    const hasCompletedOnboarding = localStorage.getItem("onboarding_complete");
    const savedPreferences = localStorage.getItem("user_preferences");

    if (!hasCompletedOnboarding) {
      setShowOnboarding(true);
    } else if (savedPreferences) {
      setUserPreferences(JSON.parse(savedPreferences));
    }

    // Simulate initial loading
    setTimeout(() => setIsLoading(false), 500);
  }, []);

  const handleOnboardingComplete = (topics: string[]) => {
    setUserPreferences(topics);
    localStorage.setItem("onboarding_complete", "true");
    localStorage.setItem("user_preferences", JSON.stringify(topics));
    setShowOnboarding(false);
  };

  const handlePreferencesSave = (topics: string[]) => {
    setUserPreferences(topics);
    localStorage.setItem("user_preferences", JSON.stringify(topics));
  };

  // Filter articles based on category, preferences, and search
  const filteredArticles = useMemo(() => {
    let articles: NewsArticle[] = [...MOCK_NEWS];

    // Filter by category
    if (selectedCategory === "my-feed") {
      // Show articles matching user preferences
      if (userPreferences.length > 0) {
        articles = articles.filter((article) =>
          userPreferences.includes(article.category)
        );
      }
    } else if (selectedCategory !== "latest") {
      // Filter by specific category
      const categoryMap: Record<string, string> = {
        technology: "Technology",
        finance: "Finance",
        global: "Global Politics",
        opinion: "Opinion",
        lifestyle: "Lifestyle",
      };
      const targetCategory = categoryMap[selectedCategory];
      if (targetCategory) {
        articles = articles.filter((article) => article.category === targetCategory);
      }
    }

    // Filter by search query
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      articles = articles.filter(
        (article) =>
          article.title.toLowerCase().includes(query) ||
          article.summary.toLowerCase().includes(query) ||
          article.category.toLowerCase().includes(query) ||
          article.source.toLowerCase().includes(query)
      );
    }

    return articles;
  }, [selectedCategory, userPreferences, searchQuery]);

  return (
    <div className="min-h-screen bg-[#0f1420]">
      {/* Onboarding Modal */}
      <OnboardingModal open={showOnboarding} onComplete={handleOnboardingComplete} />

      {/* Preferences Dialog */}
      <PreferencesDialog
        open={preferencesOpen}
        onOpenChange={setPreferencesOpen}
        currentPreferences={userPreferences}
        onSave={handlePreferencesSave}
      />

      {/* Navbar */}
      <Navbar
        onSearch={setSearchQuery}
        onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
        onOpenPreferences={() => setPreferencesOpen(true)}
      />

      {/* Sidebar */}
      <CategorySidebar
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      {/* Main Content */}
      <main className="lg:ml-64 pt-16">
        <div className="max-w-6xl mx-auto px-4 md:px-6 py-8">
          {/* Week at a Glance */}
          <WeekAtGlance />

          {/* Feed Header */}
          <div className="mb-6">
            <h1 className="text-white mb-2">
              {selectedCategory === "my-feed"
                ? "My Feed"
                : selectedCategory === "latest"
                ? "Latest News"
                : selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)}
            </h1>
            <p className="text-gray-400">
              {filteredArticles.length} article{filteredArticles.length !== 1 ? "s" : ""} found
            </p>
          </div>

          {/* News Feed */}
          <NewsFeed articles={filteredArticles} isLoading={isLoading} />
        </div>
      </main>
    </div>
  );
}
