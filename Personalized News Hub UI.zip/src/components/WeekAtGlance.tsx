import { motion } from "motion/react";
import { TrendingUp } from "lucide-react";

const HIGHLIGHTS = [
  "Global markets rebound as tech earnings exceed expectations amid rising geopolitical tensions.",
  "AI regulation summit concludes with new international framework for ethical development.",
  "Major healthcare breakthrough: New treatment shows 95% success rate in clinical trials.",
];

export function WeekAtGlance() {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-gradient-to-r from-teal-500/10 via-orange-500/10 to-teal-500/10 border border-teal-500/20 rounded-2xl p-6 mb-6"
    >
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp className="h-5 w-5 text-teal-400" />
        <h2 className="text-white">Week at a Glance</h2>
      </div>

      <div className="space-y-3">
        {HIGHLIGHTS.map((highlight, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="flex items-start gap-3"
          >
            <div className="min-w-[6px] h-6 w-1.5 bg-gradient-to-b from-teal-400 to-orange-500 rounded-full mt-0.5" />
            <p className="text-gray-300">{highlight}</p>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}
