import { NewsCard, NewsArticle } from "./NewsCard";
import { Skeleton } from "./ui/skeleton";
import { motion } from "motion/react";

interface NewsFeedProps {
  articles: NewsArticle[];
  isLoading?: boolean;
}

export function NewsFeed({ articles, isLoading }: NewsFeedProps) {
  if (isLoading) {
    return (
      <div className="grid gap-6">
        {[...Array(6)].map((_, i) => (
          <div key={i} className="bg-[#1e2438] border border-white/10 rounded-2xl p-6">
            <Skeleton className="h-6 w-24 mb-3 bg-white/10" />
            <Skeleton className="h-8 w-full mb-3 bg-white/10" />
            <Skeleton className="h-20 w-full mb-4 bg-white/10" />
            <div className="flex items-center justify-between">
              <Skeleton className="h-4 w-48 bg-white/10" />
              <Skeleton className="h-9 w-24 bg-white/10" />
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (articles.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="text-center py-16"
      >
        <p className="text-gray-400">
          No articles found. Try adjusting your filters or search terms.
        </p>
      </motion.div>
    );
  }

  return (
    <div className="grid gap-6">
      {articles.map((article, index) => (
        <NewsCard key={article.id} article={article} index={index} />
      ))}
    </div>
  );
}
