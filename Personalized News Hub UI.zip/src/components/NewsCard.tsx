import { motion } from "motion/react";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Clock, ExternalLink } from "lucide-react";

export interface NewsArticle {
  id: string;
  title: string;
  summary: string;
  category: string;
  source: string;
  publishedAt: string;
  readTime: string;
  url: string;
}

interface NewsCardProps {
  article: NewsArticle;
  index: number;
}

export function NewsCard({ article, index }: NewsCardProps) {
  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      "Technology": "bg-blue-500/20 text-blue-300 border-blue-500/30",
      "Finance": "bg-green-500/20 text-green-300 border-green-500/30",
      "AI & ML": "bg-purple-500/20 text-purple-300 border-purple-500/30",
      "Global Politics": "bg-red-500/20 text-red-300 border-red-500/30",
      "Healthcare": "bg-teal-500/20 text-teal-300 border-teal-500/30",
      "Markets": "bg-emerald-500/20 text-emerald-300 border-emerald-500/30",
      "Opinion": "bg-orange-500/20 text-orange-300 border-orange-500/30",
      "Lifestyle": "bg-pink-500/20 text-pink-300 border-pink-500/30",
    };
    return colors[category] || "bg-gray-500/20 text-gray-300 border-gray-500/30";
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      whileHover={{ y: -4 }}
      className="bg-[#1e2438] border border-white/10 rounded-2xl p-6 hover:border-teal-500/30 transition-all duration-300 shadow-lg hover:shadow-teal-500/10"
    >
      {/* Category Badge */}
      <Badge className={`mb-3 border ${getCategoryColor(article.category)}`}>
        {article.category}
      </Badge>

      {/* Title */}
      <h3 className="text-white mb-3 line-clamp-2">
        {article.title}
      </h3>

      {/* AI Summary */}
      <p className="text-gray-300 mb-4 line-clamp-3">
        {article.summary}
      </p>

      {/* Metadata Bar */}
      <div className="flex items-center justify-between pt-4 border-t border-white/10">
        <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 text-gray-400">
          <span className="flex items-center gap-1.5">
            <span>Source: {article.source}</span>
          </span>
          <span className="hidden sm:block text-white/20">•</span>
          <span className="flex items-center gap-1.5">
            <Clock className="h-3.5 w-3.5" />
            {article.publishedAt}
          </span>
          <span className="hidden sm:block text-white/20">•</span>
          <span>{article.readTime}</span>
        </div>

        <Button
          size="sm"
          className="bg-gradient-to-r from-teal-500 to-orange-500 hover:from-teal-600 hover:to-orange-600 text-white border-0"
          onClick={() => window.open(article.url, '_blank')}
        >
          Read More
          <ExternalLink className="ml-2 h-3.5 w-3.5" />
        </Button>
      </div>
    </motion.div>
  );
}
