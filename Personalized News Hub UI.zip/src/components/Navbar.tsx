import { Search, Settings, Menu } from "lucide-react";
import { Input } from "./ui/input";
import { Avatar, AvatarFallback } from "./ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { Button } from "./ui/button";

interface NavbarProps {
  onSearch: (query: string) => void;
  onToggleSidebar: () => void;
  onOpenPreferences: () => void;
}

export function Navbar({ onSearch, onToggleSidebar, onOpenPreferences }: NavbarProps) {
  return (
    <nav className="fixed top-0 left-0 right-0 h-16 bg-[#1a1f35] border-b border-white/10 z-50">
      <div className="h-full px-4 md:px-6 flex items-center gap-4">
        {/* Hamburger Menu for Mobile */}
        <Button
          variant="ghost"
          size="icon"
          onClick={onToggleSidebar}
          className="lg:hidden text-white hover:bg-white/10"
        >
          <Menu className="h-5 w-5" />
        </Button>

        {/* Logo */}
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-teal-400 to-orange-500 flex items-center justify-center">
            <span className="text-white">ED</span>
          </div>
          <span className="hidden sm:block text-white tracking-tight">
            Executive Digest
          </span>
        </div>

        {/* Search Bar */}
        <div className="flex-1 max-w-2xl mx-auto relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            type="text"
            placeholder="Search articles, topics, or keywords..."
            className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-gray-400 focus:bg-white/10"
            onChange={(e) => onSearch(e.target.value)}
          />
        </div>

        {/* Right Side Actions */}
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="icon"
            onClick={onOpenPreferences}
            className="text-white hover:bg-white/10"
          >
            <Settings className="h-5 w-5" />
          </Button>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Avatar className="cursor-pointer h-8 w-8">
                <AvatarFallback className="bg-gradient-to-br from-teal-400 to-orange-500 text-white">
                  ED
                </AvatarFallback>
              </Avatar>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48">
              <DropdownMenuLabel>My Account</DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem>Profile</DropdownMenuItem>
              <DropdownMenuItem onClick={onOpenPreferences}>
                Preferences
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem>Logout</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </nav>
  );
}
