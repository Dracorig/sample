import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Button } from "./ui/button";
import { Checkbox } from "./ui/checkbox";
import { Label } from "./ui/label";

interface OnboardingModalProps {
  open: boolean;
  onComplete: (topics: string[]) => void;
}

const TOPICS = [
  "Technology",
  "Finance",
  "Healthcare",
  "Global Politics",
  "AI & ML",
  "Supply Chain",
  "Markets",
  "Opinion",
  "Lifestyle"
];

export function OnboardingModal({ open, onComplete }: OnboardingModalProps) {
  const [selectedTopics, setSelectedTopics] = useState<string[]>([]);

  const handleToggle = (topic: string) => {
    setSelectedTopics(prev =>
      prev.includes(topic)
        ? prev.filter(t => t !== topic)
        : [...prev, topic]
    );
  };

  const handleComplete = () => {
    if (selectedTopics.length > 0) {
      onComplete(selectedTopics);
    }
  };

  return (
    <Dialog open={open} onOpenChange={() => {}}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Welcome to Executive Digest! Let's Personalize Your News.</DialogTitle>
          <DialogDescription>
            Select your primary topics of interest. You can change them later.
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 py-6">
          {TOPICS.map((topic) => (
            <div key={topic} className="flex items-center space-x-2">
              <Checkbox
                id={topic}
                checked={selectedTopics.includes(topic)}
                onCheckedChange={() => handleToggle(topic)}
              />
              <Label
                htmlFor={topic}
                className="cursor-pointer"
              >
                {topic}
              </Label>
            </div>
          ))}
        </div>

        <Button
          onClick={handleComplete}
          disabled={selectedTopics.length === 0}
          className="w-full"
        >
          Save Preferences & Start Reading
        </Button>
      </DialogContent>
    </Dialog>
  );
}
