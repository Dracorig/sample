import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "./ui/dialog";
import { Button } from "./ui/button";
import { Checkbox } from "./ui/checkbox";
import { Label } from "./ui/label";

interface PreferencesDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  currentPreferences: string[];
  onSave: (topics: string[]) => void;
}

const TOPICS = [
  "Technology",
  "Finance",
  "Healthcare",
  "Global Politics",
  "AI & ML",
  "Supply Chain",
  "Markets",
  "Opinion",
  "Lifestyle"
];

export function PreferencesDialog({ open, onOpenChange, currentPreferences, onSave }: PreferencesDialogProps) {
  const [selectedTopics, setSelectedTopics] = useState<string[]>(currentPreferences);

  const handleToggle = (topic: string) => {
    setSelectedTopics(prev =>
      prev.includes(topic)
        ? prev.filter(t => t !== topic)
        : [...prev, topic]
    );
  };

  const handleSave = () => {
    if (selectedTopics.length > 0) {
      onSave(selectedTopics);
      onOpenChange(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Update Your Preferences</DialogTitle>
          <DialogDescription>
            Select the topics you'd like to see in your personalized feed.
          </DialogDescription>
        </DialogHeader>
        
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 py-6">
          {TOPICS.map((topic) => (
            <div key={topic} className="flex items-center space-x-2">
              <Checkbox
                id={`pref-${topic}`}
                checked={selectedTopics.includes(topic)}
                onCheckedChange={() => handleToggle(topic)}
              />
              <Label
                htmlFor={`pref-${topic}`}
                className="cursor-pointer"
              >
                {topic}
              </Label>
            </div>
          ))}
        </div>

        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="flex-1"
          >
            Cancel
          </Button>
          <Button
            onClick={handleSave}
            disabled={selectedTopics.length === 0}
            className="flex-1"
          >
            Save Changes
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
