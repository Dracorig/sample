import { Home, Sparkles, Laptop, TrendingUp, Globe, MessageSquare, Heart, X } from "lucide-react";
import { Button } from "./ui/button";
import { cn } from "./ui/utils";

interface CategorySidebarProps {
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
  isOpen: boolean;
  onClose: () => void;
}

const CATEGORIES = [
  { id: "latest", label: "Latest", icon: Home },
  { id: "my-feed", label: "My Feed", icon: Sparkles },
  { id: "technology", label: "Technology", icon: Laptop },
  { id: "finance", label: "Finance", icon: TrendingUp },
  { id: "global", label: "Global", icon: Globe },
  { id: "opinion", label: "Opinion", icon: MessageSquare },
  { id: "lifestyle", label: "Lifestyle", icon: Heart },
];

export function CategorySidebar({ selectedCategory, onSelectCategory, isOpen, onClose }: CategorySidebarProps) {
  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/50 z-40"
          onClick={onClose}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed left-0 top-16 bottom-0 w-64 bg-[#1e2438] border-r border-white/10 z-40 transition-transform duration-300",
          isOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        <div className="p-4">
          {/* Close Button for Mobile */}
          <div className="lg:hidden flex justify-end mb-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={onClose}
              className="text-white hover:bg-white/10"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>

          <nav className="space-y-1">
            {CATEGORIES.map((category) => {
              const Icon = category.icon;
              return (
                <button
                  key={category.id}
                  onClick={() => {
                    onSelectCategory(category.id);
                    onClose();
                  }}
                  className={cn(
                    "w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors",
                    selectedCategory === category.id
                      ? "bg-gradient-to-r from-teal-500/20 to-orange-500/20 text-white border border-teal-500/30"
                      : "text-gray-300 hover:bg-white/5 hover:text-white"
                  )}
                >
                  <Icon className="h-5 w-5" />
                  <span>{category.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </aside>
    </>
  );
}
