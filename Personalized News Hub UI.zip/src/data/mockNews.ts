import { NewsArticle } from "../components/NewsCard";

export const MOCK_NEWS: NewsArticle[] = [
  {
    id: "1",
    title: "AI-Powered Diagnostics Revolutionize Healthcare Industry",
    summary: "New artificial intelligence systems are demonstrating unprecedented accuracy in early disease detection, potentially saving millions of lives. Major hospitals worldwide are adopting these technologies, with clinical trials showing 95% accuracy rates in identifying critical conditions.",
    category: "Healthcare",
    source: "Reuters Health",
    publishedAt: "2 hours ago",
    readTime: "5 min read",
    url: "https://example.com/article-1"
  },
  {
    id: "2",
    title: "Global Markets Rally on Strong Tech Earnings Reports",
    summary: "Major technology companies exceed quarterly expectations, driving significant market gains across global indices. Investors show renewed confidence as the sector demonstrates resilience amid economic uncertainty, with particular strength in cloud computing and AI segments.",
    category: "Finance",
    source: "Bloomberg",
    publishedAt: "4 hours ago",
    readTime: "4 min read",
    url: "https://example.com/article-2"
  },
  {
    id: "3",
    title: "Breakthrough in Quantum Computing Brings Practical Applications Closer",
    summary: "Researchers achieve stable quantum state maintenance for record-breaking duration, marking a significant milestone toward commercial quantum computers. The advancement could revolutionize cryptography, drug discovery, and complex optimization problems within the next decade.",
    category: "Technology",
    source: "TechCrunch",
    publishedAt: "6 hours ago",
    readTime: "6 min read",
    url: "https://example.com/article-3"
  },
  {
    id: "4",
    title: "International Climate Summit Reaches Historic Agreement",
    summary: "World leaders commit to ambitious carbon reduction targets with binding enforcement mechanisms. The agreement includes substantial funding for developing nations and represents the most comprehensive climate action framework to date, affecting global energy and industrial policies.",
    category: "Global Politics",
    source: "The Guardian",
    publishedAt: "8 hours ago",
    readTime: "7 min read",
    url: "https://example.com/article-4"
  },
  {
    id: "5",
    title: "Machine Learning Models Achieve Human-Level Performance in Complex Reasoning",
    summary: "Latest generation of AI systems demonstrate sophisticated problem-solving capabilities across diverse domains. The models show particular strength in mathematical reasoning, scientific analysis, and strategic planning, raising both opportunities and questions about AI governance.",
    category: "AI & ML",
    source: "MIT Technology Review",
    publishedAt: "10 hours ago",
    readTime: "8 min read",
    url: "https://example.com/article-5"
  },
  {
    id: "6",
    title: "Supply Chain Innovation: Blockchain Technology Transforms Logistics",
    summary: "Major corporations report 40% efficiency gains through blockchain-based tracking systems. The technology provides unprecedented transparency and security in global supply chains, reducing costs and improving delivery reliability across multiple industries.",
    category: "Technology",
    source: "Forbes",
    publishedAt: "12 hours ago",
    readTime: "5 min read",
    url: "https://example.com/article-6"
  },
  {
    id: "7",
    title: "Federal Reserve Signals Potential Policy Shift Amid Economic Data",
    summary: "Central bank officials indicate possible adjustments to monetary policy based on recent inflation trends and employment figures. Markets respond with cautious optimism as analysts debate implications for interest rates, bond yields, and equity valuations in coming quarters.",
    category: "Finance",
    source: "Wall Street Journal",
    publishedAt: "1 day ago",
    readTime: "6 min read",
    url: "https://example.com/article-7"
  },
  {
    id: "8",
    title: "The Future of Remote Work: Hybrid Models Redefine Corporate Culture",
    summary: "Comprehensive study reveals lasting impacts of flexible work arrangements on productivity and employee satisfaction. Companies embracing hybrid approaches report improved retention and performance, while traditional office-centric organizations face recruitment challenges.",
    category: "Opinion",
    source: "Harvard Business Review",
    publishedAt: "1 day ago",
    readTime: "9 min read",
    url: "https://example.com/article-8"
  },
  {
    id: "9",
    title: "Renewable Energy Costs Fall Below Fossil Fuels in Most Markets",
    summary: "Solar and wind power achieve cost parity with traditional energy sources across major economies. The milestone accelerates clean energy adoption and influences investment strategies, with projections showing renewables dominating new capacity additions through 2030.",
    category: "Technology",
    source: "Reuters",
    publishedAt: "1 day ago",
    readTime: "5 min read",
    url: "https://example.com/article-9"
  },
  {
    id: "10",
    title: "Stock Market Volatility: What Investors Need to Know",
    summary: "Financial experts analyze recent market fluctuations and provide guidance for navigating uncertain conditions. Key factors include geopolitical tensions, inflation concerns, and sector rotation patterns, with recommendations for portfolio diversification and risk management.",
    category: "Markets",
    source: "CNBC",
    publishedAt: "2 days ago",
    readTime: "7 min read",
    url: "https://example.com/article-10"
  },
  {
    id: "11",
    title: "Wellness Tech: How Digital Tools Are Reshaping Personal Health",
    summary: "Wearable devices and health apps empower individuals with unprecedented insights into their physical and mental wellbeing. The convergence of consumer technology and healthcare creates new opportunities for preventive medicine and personalized wellness strategies.",
    category: "Lifestyle",
    source: "Wired",
    publishedAt: "2 days ago",
    readTime: "6 min read",
    url: "https://example.com/article-11"
  },
  {
    id: "12",
    title: "Cybersecurity Threats Evolve as AI-Powered Attacks Emerge",
    summary: "Security researchers warn of sophisticated new attack vectors leveraging artificial intelligence and machine learning. Organizations invest heavily in advanced defense systems as the cybersecurity landscape becomes increasingly complex and high-stakes.",
    category: "Technology",
    source: "Dark Reading",
    publishedAt: "3 days ago",
    readTime: "8 min read",
    url: "https://example.com/article-12"
  }
];
