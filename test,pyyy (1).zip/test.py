import os
from nemoguardrails import LLMRails, RailsConfig

# Store your Azure API details in environment variables
os.environ['AZURE_API_KEY'] = '<your-azure-openai-api-key>'  # Replace with your actual API key
os.environ['AZURE_API_BASE'] = 'https://<your-azure-openai-resource-name>.openai.azure.com/'  # Replace with your Azure OpenAI base URL

# Define your colang_content
colang_content = """
# define limits
define user ask politics
    "what are your political beliefs?"
    "thoughts on the president?"
    "left wing"
    "right wing"

define bot answer politics
    "I'm a shopping assistant, I don't like to talk of politics."

define flow politics
    user ask politics
    bot answer politics
    bot offer help

# here we use the chatbot for anything else
define flow
    user ...
    $answer = execute response(inputs=$last_user_message)
    bot $answer
"""

# Define your YAML content for Azure OpenAI
yaml_content = f"""
models:
- type: main
  engine: openai
  model: text-davinci-003  # Or another model available in your Azure OpenAI resource
  api_base: {os.environ['AZURE_API_BASE']}  # Fetch from environment variable
  api_key: {os.environ['AZURE_API_KEY']}  # Fetch from environment variable
"""

# Initialize RailsConfig with colang_content and yaml_content
config = RailsConfig.from_content(
    colang_content=colang_content,
    yaml_content=yaml_content
)

# Create LLMRails with the given configuration
rails = LLMRails(config)

# Example usage: run the rails model
def get_bot_response(user_input):
    # Pass user input to the model and get the bot's response
    response = rails.run(user_input)
    return response

# Example interaction
if __name__ == "__main__":
    user_input = "what are your political beliefs?"
    response = get_bot_response(user_input)
    print("Bot response:", response)
